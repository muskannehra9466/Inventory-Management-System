# Inventory and Data Management System

Web Dev III — Lab 3. Built with Node.js, Express, MongoDB and Mongoose.

## Setup
1. Install Node.js (LTS) and MongoDB Atlas account/cluster.
2. Open this project folder in VS Code.
3. Open a terminal in this folder and run: `npm install`
4. Copy `.env.example` to a new file named `.env`.
5. In `.env`, replace the sample `MONGO_URI` with your own MongoDB Atlas connection string. Keep your password private.
6. Start the server with: `npm start`
7. Visit `http://localhost:5000` to confirm the API is running.

## API endpoints
Base URL: `http://localhost:5000`

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/products` | Create product |
| GET | `/products` | Get products |
| GET | `/products?category=Electronics` | Filter by category |
| GET | `/products?name=phone&minPrice=100&maxPrice=1000` | Filter by name and price |
| GET | `/products?page=1&limit=5&sort=price&order=asc` | Pagination and sorting |
| GET | `/products/:id` | Get one product |
| PUT | `/products/:id` | Update product details |
| PATCH | `/products/:id/stock` | Increase/decrease stock |
| DELETE | `/products/:id` | Delete product |
| GET | `/products/reports/low-stock?threshold=5` | Low-stock report |
| GET | `/products/reports/category-summary` | Category-wise aggregation |

## Sample request bodies

### Create product — POST /products
```json
{
  "name": "Wireless Mouse",
  "category": "Electronics",
  "price": 599,
  "quantity": 20,
  "description": "Wireless optical mouse"
}
```

### Update product — PUT /products/:id
```json
{
  "price": 649,
  "description": "Updated wireless mouse"
}
```

### Stock adjustment — PATCH /products/:id/stock
Restock by 10:
```json
{ "change": 10 }
```
Record a sale of 2:
```json
{ "change": -2 }
```

## Notes
- Replace `:id` with the MongoDB `_id` returned when a product is created.
- Quantity and price cannot be negative.
- Do not upload your real `.env` file or share your database password.
- `node_modules` is intentionally excluded from the ZIP. Run `npm install` after extracting.
