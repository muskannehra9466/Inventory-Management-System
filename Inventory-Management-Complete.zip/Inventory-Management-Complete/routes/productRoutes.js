const express = require('express');
const mongoose = require('mongoose');
const Product = require('../models/Product');

const router = express.Router();

// Create a product
router.post('/', async (req, res, next) => {
  try {
    const product = await Product.create(req.body);
    res.status(201).json({ success: true, message: 'Product added successfully', product });
  } catch (error) { next(error); }
});

// Get all products with filtering, sorting and pagination
router.get('/', async (req, res, next) => {
  try {
    const { category, name, minPrice, maxPrice, sort = 'createdAt', order = 'desc' } = req.query;
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);
    const filter = {};

    if (category) filter.category = new RegExp(category, 'i');
    if (name) filter.name = new RegExp(name, 'i');
    if (minPrice !== undefined || maxPrice !== undefined) {
      filter.price = {};
      if (minPrice !== undefined) filter.price.$gte = Number(minPrice);
      if (maxPrice !== undefined) filter.price.$lte = Number(maxPrice);
    }

    const sortOrder = order.toLowerCase() === 'asc' ? 1 : -1;
    const allowedSort = ['name', 'category', 'price', 'quantity', 'createdAt'];
    const sortField = allowedSort.includes(sort) ? sort : 'createdAt';

    const [products, total] = await Promise.all([
      Product.find(filter).sort({ [sortField]: sortOrder }).skip((page - 1) * limit).limit(limit),
      Product.countDocuments(filter)
    ]);

    res.json({
      success: true,
      count: products.length,
      total,
      page,
      totalPages: Math.ceil(total / limit),
      products
    });
  } catch (error) { next(error); }
});

// Low-stock report (threshold can be changed with ?threshold=5)
router.get('/reports/low-stock', async (req, res, next) => {
  try {
    const threshold = Math.max(Number(req.query.threshold) || 5, 0);
    const products = await Product.find({ quantity: { $lte: threshold } }).sort({ quantity: 1 });
    res.json({ success: true, threshold, count: products.length, products });
  } catch (error) { next(error); }
});

// Category-wise inventory summary using aggregation
router.get('/reports/category-summary', async (req, res, next) => {
  try {
    const summary = await Product.aggregate([
      { $group: {
        _id: '$category',
        totalProducts: { $sum: 1 },
        totalQuantity: { $sum: '$quantity' },
        totalInventoryValue: { $sum: { $multiply: ['$price', '$quantity'] } }
      }},
      { $sort: { _id: 1 } },
      { $project: {
        _id: 0,
        category: '$_id',
        totalProducts: 1,
        totalQuantity: 1,
        totalInventoryValue: 1
      }}
    ]);
    res.json({ success: true, summary });
  } catch (error) { next(error); }
});

// Get one product by ID
router.get('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: 'Invalid product ID' });
    }
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
    res.json({ success: true, product });
  } catch (error) { next(error); }
});

// Update product details
router.put('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: 'Invalid product ID' });
    }
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, {
      new: true, runValidators: true
    });
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
    res.json({ success: true, message: 'Product updated successfully', product });
  } catch (error) { next(error); }
});

// Restock or record a sale: { "change": 10 } or { "change": -2 }
router.patch('/:id/stock', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: 'Invalid product ID' });
    }
    const change = Number(req.body.change);
    if (!Number.isInteger(change) || change === 0) {
      return res.status(400).json({ success: false, message: 'change must be a non-zero whole number' });
    }
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
    if (product.quantity + change < 0) {
      return res.status(400).json({ success: false, message: 'Insufficient stock for this sale' });
    }
    product.quantity += change;
    await product.save();
    res.json({ success: true, message: change > 0 ? 'Stock restocked successfully' : 'Sale recorded successfully', product });
  } catch (error) { next(error); }
});

// Delete a product
router.delete('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: 'Invalid product ID' });
    }
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });
    res.json({ success: true, message: 'Product deleted successfully' });
  } catch (error) { next(error); }
});

module.exports = router;
