function notFound(req, res, next) {
  res.status(404);
  next(new Error(`Route not found: ${req.originalUrl}`));
}

function errorHandler(err, req, res, next) {
  let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  let message = err.message || 'Server Error';

  if (err.name === 'ValidationError') {
    statusCode = 400;
    message = Object.values(err.errors).map(item => item.message).join(', ');
  } else if (err.name === 'CastError') {
    statusCode = 400;
    message = 'Invalid product ID';
  } else if (err.code === 11000) {
    statusCode = 400;
    message = 'Duplicate value';
  }

  res.status(statusCode).json({ success: false, message });
}

module.exports = { notFound, errorHandler };
